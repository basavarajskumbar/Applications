Copyright
--------------

Elite WordPress Theme, Copyright 2015 WooRockets.com
Elite is based on Underscores http://underscores.me/, (C) 2012-2013 Automattic, Inc.
This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.


Install Steps
--------------

1. Upload the theme
2. Activate the theme


Licenses
--------------

TGM Plugin Activation: Licensed under the GPL-2.0 or later license

Fontello: Distributed under MIT license

jQuery JSON Plugin: MIT License: http://www.opensource.org/licenses/mit-license.php

Bootstrap 3: MIT license

OWL Carousel: MIT License - http://www.opensource.org/licenses/mit-license.php

jQuery Countdown: Dual licensed under the MIT and GPL-3.0 

jQuery Single Page Nav: MIT license

Respond.js v1.1.0: MIT/GPLv2 License
